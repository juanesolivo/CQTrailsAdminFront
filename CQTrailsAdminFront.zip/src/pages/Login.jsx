import React, { useState } from 'react';

const Login = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        // Aquí puedes hacer la llamada a tu API de FastAPI para la autorización
        console.log('Email:', email);
        console.log('Password:', password);
    };

    return (
        <div>
            <h1>Iniciar Sesión</h1>
            <form onSubmit={handleSubmit}>
                <label>
                    Correo Electrónico
                    <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="Dirección de correo electrónico"
                        required
                    />
                </label>
                <label>
                    Contraseña
                    <input
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="Tu contraseña"
                        required
                    />
                </label>
                <button type="submit">Ingresar</button>
            </form>
            <p>
                ¿Olvidaste tu Contraseña? <a href="#">Recuperar Contraseña</a>
            </p>
        </div>
    );
};

export default Login;
